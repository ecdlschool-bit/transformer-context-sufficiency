# Reviewer Robustness Checks
A1 source-supported counterfactuals
A2 token-map robustness
A3 probe sweep
A4 boundary audit
